

class Params:
    """
    Represents an auxiliary class for storing parameters.
    """
    pass